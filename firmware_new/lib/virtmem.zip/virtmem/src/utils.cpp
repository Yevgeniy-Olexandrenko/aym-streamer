#include "config/config.h"
#include "internal/vptr_utils.h"

namespace virtmem {

const NILL_t NILL = NILL_t(); // need empty constructor to prevent compiler error on arduino

}
